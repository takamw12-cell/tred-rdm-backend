import { Route, Switch, Redirect } from "wouter";
import { Loader2 } from "lucide-react";
import { Provider } from "./components/provider";
import { AppLayout } from "./components/layout";
import { useUserStore } from "./stores/user";
import { authClient } from "./lib/auth";
import { LogoMark } from "./components/logo";
import OnboardingPage from "./pages/onboarding";
import LoginPage from "./pages/login";
import DashboardPage from "./pages/dashboard";
import ChatPage from "./pages/chat";
import DictionaryPage from "./pages/dictionary";
import DnaPage from "./pages/dna";
import ExercisesPage from "./pages/exercises";
import FormulasPage from "./pages/formulas";
import ExamPage from "./pages/exam";
import SettingsPage from "./pages/settings";
import PricingPage from "./pages/pricing";
import AdminPage from "./pages/admin";

function RootRedirect() {
  const onboarded = useUserStore((s) => s.onboarded);
  return <Redirect to={onboarded ? "/dashboard" : "/onboarding"} />;
}

function LoadingScreen() {
  return (
    <div className="flex min-h-screen flex-col items-center justify-center gap-4">
      <LogoMark className="size-12 animate-pulse" />
      <Loader2 className="text-muted-foreground size-5 animate-spin" />
    </div>
  );
}

function AuthedApp() {
  return (
    <Switch>
      <Route path="/" component={RootRedirect} />
      <Route path="/onboarding" component={OnboardingPage} />
      <Route path="/exam" component={ExamPage} />
      <Route>
        <AppLayout>
          <Switch>
            <Route path="/dashboard" component={DashboardPage} />
            <Route path="/chat" component={ChatPage} />
            <Route path="/dictionary" component={DictionaryPage} />
            <Route path="/dna" component={DnaPage} />
            <Route path="/exercises" component={ExercisesPage} />
            <Route path="/formulas" component={FormulasPage} />
            <Route path="/settings" component={SettingsPage} />
            <Route path="/pricing" component={PricingPage} />
            {/* Serverseitig durch die Admin-Rolle geschützt, nicht durch Verstecken. */}
            <Route path="/admin" component={AdminPage} />
            <Route component={RootRedirect} />
          </Switch>
        </AppLayout>
      </Route>
    </Switch>
  );
}

function Gate() {
  const { data: session, isPending } = authClient.useSession();
  if (isPending) return <LoadingScreen />;
  if (!session) return <LoginPage />;
  return <AuthedApp />;
}

function App() {
  return (
    <Provider>
      <Gate />
    </Provider>
  );
}

export default App;
