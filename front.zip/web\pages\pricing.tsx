import { motion } from "framer-motion";
import { Check, Minus, Sparkles, Crown } from "lucide-react";
import { PageContainer, PageHeader, Reveal } from "@/components/page";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useT } from "@/i18n";
import { useUserStore, type PlanId } from "@/stores/user";
import { cn } from "@/lib/utils";

interface PlanDef {
  id: PlanId;
  popular?: boolean;
  featured?: boolean;
}

const plans: PlanDef[] = [
  { id: "free" },
  { id: "standard", popular: true },
  { id: "premium", featured: true },
];

type FeatureKey = "chat" | "dictionary" | "dna" | "exam" | "documents" | "support" | "offline";
const featureKeys: FeatureKey[] = ["chat", "dictionary", "dna", "exam", "documents", "support", "offline"];

// value: true = included, false = not, "limited"/"unlimited" = text key
type Cell = boolean | "limited" | "unlimited";
const matrix: Record<PlanId, Record<FeatureKey, Cell>> = {
  founder: { chat: "unlimited", dictionary: true, dna: true, exam: true, documents: true, support: true, offline: true },
  free: { chat: "limited", dictionary: true, dna: false, exam: false, documents: false, support: false, offline: false },
  standard: { chat: "unlimited", dictionary: true, dna: true, exam: true, documents: true, support: false, offline: false },
  premium: { chat: "unlimited", dictionary: true, dna: true, exam: true, documents: true, support: true, offline: true },
};

const planFeatureList: Record<PlanId, FeatureKey[]> = {
  founder: featureKeys,
  free: ["chat", "dictionary"],
  standard: ["chat", "dictionary", "dna", "exam", "documents"],
  premium: featureKeys,
};

export default function PricingPage() {
  const { t } = useT();
  const currentPlan = useUserStore((s) => s.plan);
  const setPlan = useUserStore((s) => s.setPlan);

  return (
    <PageContainer>
      <PageHeader title={t("pricing.title")} subtitle={t("pricing.subtitle")} />

      <div className="grid gap-5 md:grid-cols-3">
        {plans.map((plan, i) => {
          const isCurrent = currentPlan === plan.id;
          return (
            <motion.div
              key={plan.id}
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.35, delay: i * 0.08, ease: [0.16, 1, 0.3, 1] }}
            >
              <Card
                className={cn(
                  "relative flex h-full flex-col p-6",
                  plan.featured && "border-primary/60 shadow-lg",
                )}
              >
                {plan.popular && (
                  <Badge className="brand-gradient absolute -top-3 left-1/2 -translate-x-1/2 border-0 text-white">
                    <Sparkles className="size-3" />
                    {t("pricing.mostPopular")}
                  </Badge>
                )}
                <div className="mb-4">
                  <div className="flex items-center gap-2">
                    {plan.featured && <Crown className="text-primary size-4" />}
                    <h3 className="font-display text-xl font-extrabold">{t(`pricing.plans.${plan.id}.name`)}</h3>
                  </div>
                  <div className="mt-3 flex items-baseline gap-1 whitespace-nowrap">
                    <span className="font-display text-4xl font-extrabold tracking-tight">
                      {t(`pricing.plans.${plan.id}.price`)}
                    </span>
                    {plan.id !== "free" && (
                      <span className="text-muted-foreground text-sm">{t("pricing.perMonth")}</span>
                    )}
                  </div>
                  <p className="text-muted-foreground mt-2 text-sm">{t(`pricing.plans.${plan.id}.desc`)}</p>
                </div>

                <ul className="mb-6 space-y-2.5">
                  {planFeatureList[plan.id].map((f) => (
                    <li key={f} className="flex items-center gap-2.5 text-sm">
                      <span className="bg-mastered/15 text-mastered grid size-5 shrink-0 place-items-center rounded-full">
                        <Check className="size-3" />
                      </span>
                      {t(`pricing.features.${f}`)}
                      {matrix[plan.id][f] === "limited" && (
                        <span className="text-muted-foreground text-xs">({t("pricing.limited")})</span>
                      )}
                    </li>
                  ))}
                </ul>

                <div className="mt-auto">
                  <Button
                    className={cn("w-full", plan.featured && "brand-gradient text-white")}
                    variant={plan.featured ? "default" : "outline"}
                    disabled={isCurrent}
                    onClick={() => setPlan(plan.id)}
                  >
                    {isCurrent ? t("pricing.currentPlan") : t("pricing.choose")}
                  </Button>
                </div>
              </Card>
            </motion.div>
          );
        })}
      </div>

      {/* Comparison table */}
      <Reveal className="mt-10">
        <h2 className="font-display mb-4 text-lg font-bold">{t("pricing.compare")}</h2>
        <Card className="overflow-hidden p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-border border-b">
                  <th className="px-4 py-3 text-left font-semibold">{t("pricing.feature")}</th>
                  {plans.map((p) => (
                    <th key={p.id} className="px-4 py-3 text-center font-semibold">
                      {t(`pricing.plans.${p.id}.name`)}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {featureKeys.map((f) => (
                  <tr key={f} className="border-border/60 border-b last:border-0">
                    <td className="px-4 py-3 font-medium">{t(`pricing.features.${f}`)}</td>
                    {plans.map((p) => (
                      <td key={p.id} className="px-4 py-3 text-center">
                        <CellView value={matrix[p.id][f]} limitedLabel={t("pricing.limited")} unlimitedLabel={t("pricing.unlimited")} />
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>
      </Reveal>

      <Reveal className="mt-6 text-center">
        <p className="text-muted-foreground text-xs">{t("pricing.paymentMethods")}: Visa · Mastercard · PayPal · SEPA</p>
      </Reveal>
    </PageContainer>
  );
}

function CellView({ value, limitedLabel, unlimitedLabel }: { value: Cell; limitedLabel: string; unlimitedLabel: string }) {
  if (value === true)
    return (
      <span className="text-mastered inline-flex">
        <Check className="size-4" />
      </span>
    );
  if (value === false)
    return (
      <span className="text-muted-foreground/40 inline-flex">
        <Minus className="size-4" />
      </span>
    );
  return (
    <span className="text-muted-foreground text-xs font-medium">
      {value === "limited" ? limitedLabel : unlimitedLabel}
    </span>
  );
}
