import { sql } from "drizzle-orm";
import { index, integer, sqliteTable, text, uniqueIndex } from "drizzle-orm/sqlite-core";

import { user } from "./auth.schema";

export type PushPlatform = "ios" | "android";

export const pushTokens = sqliteTable(
  "push_tokens",
  {
    id: text("id")
      .primaryKey()
      .$defaultFn(() => crypto.randomUUID()),

    userId: text("user_id")
      .notNull()
      .references(() => user.id, { onDelete: "cascade" }),

    /**
     * Token Expo (`ExponentPushToken[xxxxxxxx]`) ou token FCM natif.
     * UNIQUE : si l'appareil change de propriétaire (déconnexion / reconnexion
     * avec un autre compte), l'upsert réassigne le token au nouveau userId
     * au lieu de créer un doublon qui enverrait la notif à la mauvaise personne.
     */
    pushToken: text("push_token").notNull(),

    platform: text("platform").$type<PushPlatform>().notNull(),

    /** Optionnel mais très utile pour debug côté support. */
    deviceName: text("device_name"),
    appVersion: text("app_version"),

    createdAt: integer("created_at", { mode: "timestamp" })
      .notNull()
      .default(sql`(unixepoch())`),

    updatedAt: integer("updated_at", { mode: "timestamp" })
      .notNull()
      .default(sql`(unixepoch())`),
  },
  (table) => [
    uniqueIndex("push_tokens_token_unique").on(table.pushToken),
    index("push_tokens_user_id_idx").on(table.userId),
  ],
);

export type PushTokenRow = typeof pushTokens.$inferSelect;
export type NewPushToken = typeof pushTokens.$inferInsert;
