import { Hono, type Context } from "hono";
import type Stripe from "stripe";
import { eq } from "drizzle-orm";
import { z } from "zod";

import { auth } from "../auth"; // Better Auth — adapte le chemin si besoin
import { db } from "../db";
import { subscriptions, type SubscriptionStatus } from "../db/schema/subscriptions";
import {
  extractId,
  getStripe,
  resolveCurrentPeriodEnd,
  stripeTimestampToDate,
} from "../lib/stripe";
import { getEntitlement } from "../lib/entitlements";

/**
 * Routes Stripe montées en Hono brut.
 *
 * Pourquoi Hono et pas oRPC pour tout : le webhook a besoin du **corps brut**
 * (`c.req.text()`) pour vérifier la signature. Un routeur RPC parse le JSON en
 * amont et casse la vérification. On garde donc :
 *   - `/webhook`        -> Hono pur, public
 *   - `/create-checkout`-> Hono + session Better Auth (équivalent protectedProcedure)
 *   - `/me`             -> statut d'abonnement + quota, pour l'écran Paywall
 *
 * La version oRPC des routes protégées est dans
 * `routers/subscriptions.router.ts` si tu préfères passer par ton router.
 */

type AppEnv = {
  Variables: {
    user?: { id: string; email: string } | null;
    session?: unknown;
  };
};

export const subscriptionsRoutes = new Hono<AppEnv>();

const createCheckoutSchema = z.object({
  priceId: z.string().min(1, "priceId requis"),
  successUrl: z.string().url().optional(),
  cancelUrl: z.string().url().optional(),
});

/** Récupère l'utilisateur courant depuis Better Auth. */
async function requireUser(c: Context<AppEnv>) {
  // Si ton middleware global pose déjà `c.get("user")`, on le réutilise.
  const fromContext = c.get("user");
  if (fromContext?.id) return fromContext;

  const session = await auth.api.getSession({ headers: c.req.raw.headers });
  return session?.user ?? null;
}

/**
 * Retrouve ou crée le customer Stripe de l'utilisateur.
 * Idempotent : on réutilise toujours le customer déjà stocké en base.
 */
async function getOrCreateStripeCustomer(user: { id: string; email?: string | null; name?: string | null }) {
  const stripe = getStripe();

  const [existing] = await db
    .select()
    .from(subscriptions)
    .where(eq(subscriptions.userId, user.id))
    .limit(1);

  if (existing?.stripeCustomerId) {
    return existing.stripeCustomerId;
  }

  const customer = await stripe.customers.create({
    email: user.email ?? undefined,
    name: user.name ?? undefined,
    metadata: { userId: user.id },
  });

  await db
    .insert(subscriptions)
    .values({
      userId: user.id,
      stripeCustomerId: customer.id,
      status: "incomplete",
    })
    .onConflictDoUpdate({
      target: subscriptions.userId,
      set: { stripeCustomerId: customer.id, updatedAt: new Date() },
    });

  return customer.id;
}

/* -------------------------------------------------------------------------- */
/* POST /api/subscriptions/create-checkout            (protégé)                */
/* -------------------------------------------------------------------------- */

subscriptionsRoutes.post("/create-checkout", async (c) => {
  const user = await requireUser(c);
  if (!user) {
    return c.json({ error: "UNAUTHORIZED" }, 401);
  }

  const parsed = createCheckoutSchema.safeParse(await c.req.json().catch(() => ({})));
  if (!parsed.success) {
    return c.json({ error: "BAD_REQUEST", issues: parsed.error.flatten() }, 400);
  }

  const { priceId, successUrl, cancelUrl } = parsed.data;
  const appUrl = process.env.APP_URL ?? "https://tred.app";

  try {
    const stripe = getStripe();
    const customerId = await getOrCreateStripeCustomer(user);

    const session = await stripe.checkout.sessions.create(
      {
        mode: "subscription",
        customer: customerId,
        line_items: [{ price: priceId, quantity: 1 }],
        // `client_reference_id` + metadata : deux filets de sécurité pour
        // retrouver l'utilisateur dans le webhook.
        client_reference_id: user.id,
        metadata: { userId: user.id },
        subscription_data: { metadata: { userId: user.id } },
        allow_promotion_codes: true,
        success_url: successUrl ?? `${appUrl}/subscription/success?session_id={CHECKOUT_SESSION_ID}`,
        cancel_url: cancelUrl ?? `${appUrl}/subscription/cancel`,
      },
      // Évite les doublons si l'app mobile double-tape le bouton.
      { idempotencyKey: `checkout:${user.id}:${priceId}:${Math.floor(Date.now() / 60_000)}` },
    );

    return c.json({ url: session.url, sessionId: session.id });
  } catch (error) {
    console.error("[stripe] create-checkout échoué:", error);
    return c.json({ error: "STRIPE_CHECKOUT_FAILED" }, 502);
  }
});

/* -------------------------------------------------------------------------- */
/* POST /api/subscriptions/portal                     (protégé)                */
/* -------------------------------------------------------------------------- */

subscriptionsRoutes.post("/portal", async (c) => {
  const user = await requireUser(c);
  if (!user) return c.json({ error: "UNAUTHORIZED" }, 401);

  try {
    const [row] = await db
      .select()
      .from(subscriptions)
      .where(eq(subscriptions.userId, user.id))
      .limit(1);

    if (!row?.stripeCustomerId) {
      return c.json({ error: "NO_CUSTOMER" }, 404);
    }

    const portal = await getStripe().billingPortal.sessions.create({
      customer: row.stripeCustomerId,
      return_url: `${process.env.APP_URL ?? "https://tred.app"}/settings`,
    });

    return c.json({ url: portal.url });
  } catch (error) {
    console.error("[stripe] portal échoué:", error);
    return c.json({ error: "STRIPE_PORTAL_FAILED" }, 502);
  }
});

/* -------------------------------------------------------------------------- */
/* GET /api/subscriptions/me                          (protégé)                */
/* -------------------------------------------------------------------------- */

subscriptionsRoutes.get("/me", async (c) => {
  const user = await requireUser(c);
  if (!user) return c.json({ error: "UNAUTHORIZED" }, 401);

  const entitlement = await getEntitlement(user.id);

  return c.json({
    isPro: entitlement.isPro,
    status: entitlement.status,
    currentPeriodEnd: entitlement.currentPeriodEnd?.toISOString() ?? null,
    tokensUsed: entitlement.tokensUsed,
    tokensQuota: Number.isFinite(entitlement.tokensQuota) ? entitlement.tokensQuota : null,
    canUseAI: entitlement.canUseAI,
  });
});

/* -------------------------------------------------------------------------- */
/* POST /api/subscriptions/webhook                    (PUBLIC — pas d'auth)    */
/* -------------------------------------------------------------------------- */

/** Upsert d'un abonnement à partir d'un objet Stripe.Subscription. */
async function upsertFromSubscription(subscription: Stripe.Subscription) {
  const stripe = getStripe();

  const customerId = extractId(subscription.customer);
  if (!customerId) {
    console.error("[stripe webhook] subscription sans customer:", subscription.id);
    return;
  }

  // 1) metadata (posée au checkout), 2) fallback: lookup par customerId en base,
  // 3) dernier recours: metadata du customer Stripe.
  let userId = subscription.metadata?.userId ?? null;

  if (!userId) {
    const [row] = await db
      .select({ userId: subscriptions.userId })
      .from(subscriptions)
      .where(eq(subscriptions.stripeCustomerId, customerId))
      .limit(1);
    userId = row?.userId ?? null;
  }

  if (!userId) {
    const customer = await stripe.customers.retrieve(customerId);
    if (!customer.deleted) {
      userId = customer.metadata?.userId ?? null;
    }
  }

  if (!userId) {
    console.error("[stripe webhook] impossible de résoudre userId pour customer:", customerId);
    return;
  }

  const periodEnd = stripeTimestampToDate(resolveCurrentPeriodEnd(subscription));
  const priceId = subscription.items?.data?.[0]?.price?.id ?? null;

  await db
    .insert(subscriptions)
    .values({
      userId,
      stripeCustomerId: customerId,
      stripeSubscriptionId: subscription.id,
      stripePriceId: priceId,
      status: subscription.status as SubscriptionStatus,
      currentPeriodEnd: periodEnd,
      cancelAtPeriodEnd: subscription.cancel_at_period_end ?? false,
      updatedAt: new Date(),
    })
    .onConflictDoUpdate({
      target: subscriptions.userId,
      set: {
        stripeCustomerId: customerId,
        stripeSubscriptionId: subscription.id,
        stripePriceId: priceId,
        status: subscription.status as SubscriptionStatus,
        currentPeriodEnd: periodEnd,
        cancelAtPeriodEnd: subscription.cancel_at_period_end ?? false,
        updatedAt: new Date(),
      },
    });

  console.log(
    `[stripe webhook] user=${userId} status=${subscription.status} periodEnd=${periodEnd?.toISOString() ?? "null"}`,
  );
}

subscriptionsRoutes.post("/webhook", async (c) => {
  const signature = c.req.header("stripe-signature");
  const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET;

  if (!signature || !webhookSecret) {
    console.error("[stripe webhook] signature ou STRIPE_WEBHOOK_SECRET manquant");
    return c.json({ received: false, error: "MISSING_SIGNATURE" }, 400);
  }

  // Corps BRUT obligatoire pour la vérification de signature.
  const rawBody = await c.req.text();

  let event: Stripe.Event;
  try {
    event = await getStripe().webhooks.constructEventAsync(rawBody, signature, webhookSecret);
  } catch (error) {
    // Signature invalide => 400, Stripe ne retentera pas indéfiniment.
    console.error("[stripe webhook] signature invalide:", error);
    return c.json({ received: false, error: "INVALID_SIGNATURE" }, 400);
  }

  try {
    switch (event.type) {
      case "checkout.session.completed": {
        const session = event.data.object as Stripe.Checkout.Session;
        const subscriptionId = extractId(session.subscription);

        if (!subscriptionId) {
          console.warn("[stripe webhook] checkout.session.completed sans subscription (paiement one-shot ?)");
          break;
        }

        // On relit la subscription : la session Checkout ne porte pas la période.
        const subscription = await getStripe().subscriptions.retrieve(subscriptionId);

        // Propage le userId de la session vers la subscription si absent.
        const userId = session.metadata?.userId ?? session.client_reference_id ?? null;
        if (userId && !subscription.metadata?.userId) {
          subscription.metadata = { ...subscription.metadata, userId };
        }

        await upsertFromSubscription(subscription);
        break;
      }

      case "customer.subscription.created":
      case "customer.subscription.updated":
      case "customer.subscription.deleted": {
        // `deleted` arrive avec status "canceled" : le même upsert suffit,
        // l'accès Pro tombe automatiquement via status + currentPeriodEnd.
        await upsertFromSubscription(event.data.object as Stripe.Subscription);
        break;
      }

      case "invoice.payment_failed": {
        const invoice = event.data.object as Stripe.Invoice;
        const customerId = extractId(invoice.customer);
        if (customerId) {
          await db
            .update(subscriptions)
            .set({ status: "past_due", updatedAt: new Date() })
            .where(eq(subscriptions.stripeCustomerId, customerId));
        }
        break;
      }

      default:
        // Événement non géré : on l'ignore silencieusement mais on ACK.
        break;
    }
  } catch (error) {
    // Contrainte du cahier des charges : ne JAMAIS planter le serveur.
    // On log et on renvoie 200 pour éviter les retries en boucle sur un bug
    // applicatif (une erreur transitoire réseau reste visible dans les logs).
    console.error(`[stripe webhook] échec du traitement de ${event.type}:`, error);
    return c.json({ received: true, handled: false }, 200);
  }

  return c.json({ received: true, handled: true }, 200);
});

export default subscriptionsRoutes;
