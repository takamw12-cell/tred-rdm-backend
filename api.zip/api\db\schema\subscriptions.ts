import { sql } from "drizzle-orm";
import { index, integer, sqliteTable, text } from "drizzle-orm/sqlite-core";

// Better Auth user table. Adapte le chemin si ton fichier s'appelle autrement
// (ex: "./auth.schema" ou "./user.schema").
import { user } from "./auth.schema";

/**
 * Statuts Stripe possibles. On stocke en `text` libre (Turso/SQLite) mais on
 * type le champ pour garder l'autocomplétion côté TS.
 */
export type SubscriptionStatus =
  | "incomplete"
  | "incomplete_expired"
  | "trialing"
  | "active"
  | "past_due"
  | "canceled"
  | "unpaid"
  | "paused";

export const subscriptions = sqliteTable(
  "subscriptions",
  {
    id: text("id")
      .primaryKey()
      .$defaultFn(() => crypto.randomUUID()),

    userId: text("user_id")
      .notNull()
      .references(() => user.id, { onDelete: "cascade" }),

    stripeCustomerId: text("stripe_customer_id").notNull(),
    stripeSubscriptionId: text("stripe_subscription_id"),

    /** Price Stripe actuellement souscrit (utile pour distinguer mensuel/annuel). */
    stripePriceId: text("stripe_price_id"),

    status: text("status").$type<SubscriptionStatus>().notNull().default("incomplete"),

    /** Fin de la période payée en cours. C'est CE champ qui fait foi pour l'accès Pro. */
    currentPeriodEnd: integer("current_period_end", { mode: "timestamp" }),

    /** true si l'utilisateur a demandé l'annulation mais garde l'accès jusqu'à la fin de période. */
    cancelAtPeriodEnd: integer("cancel_at_period_end", { mode: "boolean" })
      .notNull()
      .default(false),

    createdAt: integer("created_at", { mode: "timestamp" })
      .notNull()
      .default(sql`(unixepoch())`),

    updatedAt: integer("updated_at", { mode: "timestamp" })
      .notNull()
      .default(sql`(unixepoch())`),
  },
  (table) => [
    // Un seul enregistrement d'abonnement par user : permet l'upsert
    // `onConflictDoUpdate({ target: subscriptions.userId })`.
    index("subscriptions_user_id_unique").on(table.userId),
    index("subscriptions_stripe_customer_id_idx").on(table.stripeCustomerId),
    index("subscriptions_stripe_subscription_id_idx").on(table.stripeSubscriptionId),
  ],
);

export type Subscription = typeof subscriptions.$inferSelect;
export type NewSubscription = typeof subscriptions.$inferInsert;

/** Statuts qui donnent réellement accès aux fonctionnalités Pro. */
export const ACTIVE_SUBSCRIPTION_STATUSES: SubscriptionStatus[] = ["active", "trialing"];
