import { ORPCError } from "@orpc/server";
import { and, eq } from "drizzle-orm";
import { z } from "zod";

import { protectedProcedure } from "../../trpc";

import { db } from "../db";
import { pushTokens } from "../db/schema/push_tokens";
import { sendNotification } from "../lib/push";

const registerTokenInput = z.object({
  pushToken: z.string().min(1),
  platform: z.enum(["ios", "android"]),
  deviceName: z.string().max(120).optional(),
  appVersion: z.string().max(40).optional(),
});

export const notificationsRouter = {
  registerToken: protectedProcedure
    .input(registerTokenInput)
    .handler(async ({ input, context }) => {
      try {
        await db
          .insert(pushTokens)
          .values({
            userId: context.session.user.id,
            pushToken: input.pushToken,
            platform: input.platform,
            deviceName: input.deviceName,
            appVersion: input.appVersion,
          })
          .onConflictDoUpdate({
            target: pushTokens.pushToken,
            set: {
              userId: context.session.user.id,
              platform: input.platform,
              deviceName: input.deviceName,
              appVersion: input.appVersion,
              updatedAt: new Date(),
            },
          });

        return { success: true };
      } catch (error) {
        console.error("[notifications] registerToken échoué:", error);
        throw new ORPCError("INTERNAL_SERVER_ERROR", {
          message: "Enregistrement du token impossible",
        });
      }
    }),

  unregisterToken: protectedProcedure
    .input(z.object({ pushToken: z.string().min(1) }))
    .handler(async ({ input, context }) => {
      await db
        .delete(pushTokens)
        .where(
          and(
            eq(pushTokens.userId, context.session.user.id),
            eq(pushTokens.pushToken, input.pushToken),
          ),
        );
      return { success: true };
    }),

  /** Test d'envoi vers ses propres appareils uniquement. */
  test: protectedProcedure.handler(async ({ context }) => {
    return sendNotification({
      userId: context.session.user.id,
      title: "TRED — test",
      body: "Si tu vois ça, les push fonctionnent 🎉",
      data: { type: "test" },
    });
  }),
};

/* ==========================================================================
 * ÉQUIVALENT tRPC v11 :
 *
 * export const notificationsRouter = router({
 *   registerToken: protectedProcedure
 *     .input(registerTokenInput)
 *     .mutation(async ({ input, ctx }) => { ...  ctx.session.user.id ... }),
 * });
 * ========================================================================== */
