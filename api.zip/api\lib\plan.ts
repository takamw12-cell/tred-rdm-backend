import { and, eq, sql } from "drizzle-orm";
import { db } from "../database";
import { document, usageCounter, userPlan } from "../database/schema";

export type PlanId = "founder" | "free" | "standard" | "premium";
export type Metric = "chat" | "exercise" | "video" | "formulas";

/**
 * Monthly allowances per plan, plus the total number of documents that can be
 * stored. The caps are deliberately conservative: every AI answer carries the
 * course documents as context, so an uncapped plan can cost far more than the
 * subscription price. They also protect the account against runaway usage.
 */
export const LIMITS: Record<PlanId, Record<Metric | "documents", number>> = {
  free: { chat: 15, exercise: 2, video: 1, formulas: 1, documents: 2 },
  standard: { chat: 150, exercise: 25, video: 8, formulas: 15, documents: 20 },
  premium: { chat: 400, exercise: 80, video: 25, formulas: 40, documents: 60 },
  // Early adopters: same generous allowance as Premium.
  founder: { chat: 400, exercise: 80, video: 25, formulas: 40, documents: 60 },
};

const PLAN_IDS: PlanId[] = ["founder", "free", "standard", "premium"];

/** Current billing period, e.g. "2026-07". Counters reset on the 1st. */
export function currentPeriod(now = new Date()): string {
  return `${now.getUTCFullYear()}-${String(now.getUTCMonth() + 1).padStart(2, "0")}`;
}

/**
 * Effective plan for a user. Falls back to "free" when nothing is stored or
 * when a paid period has expired, so access can never be granted by accident.
 */
export async function getPlan(userId: string): Promise<PlanId> {
  const rows = await db
    .select()
    .from(userPlan)
    .where(eq(userPlan.userId, userId))
    .limit(1);
  if (rows.length === 0) return "free";

  const row = rows[0];
  const plan = PLAN_IDS.includes(row.plan as PlanId) ? (row.plan as PlanId) : "free";
  if (plan === "free") return "free";
  if (row.validUntil && row.validUntil.getTime() < Date.now()) return "free";
  return plan;
}

export async function getUsage(
  userId: string,
): Promise<Record<Metric, number>> {
  const rows = await db
    .select()
    .from(usageCounter)
    .where(
      and(
        eq(usageCounter.userId, userId),
        eq(usageCounter.period, currentPeriod()),
      ),
    );
  const usage: Record<Metric, number> = {
    chat: 0,
    exercise: 0,
    video: 0,
    formulas: 0,
  };
  for (const r of rows) {
    if (r.metric in usage) usage[r.metric as Metric] = r.count;
  }
  return usage;
}

export interface QuotaResult {
  ok: boolean;
  plan: PlanId;
  used: number;
  limit: number;
}

/**
 * Check the monthly allowance and, when there is room left, count this call.
 * Returns ok:false when the allowance is exhausted — the caller answers 402
 * so the interface can invite an upgrade.
 */
export async function consume(
  userId: string,
  metric: Metric,
): Promise<QuotaResult> {
  const plan = await getPlan(userId);
  const limit = LIMITS[plan][metric];
  const period = currentPeriod();

  const rows = await db
    .select()
    .from(usageCounter)
    .where(
      and(
        eq(usageCounter.userId, userId),
        eq(usageCounter.period, period),
        eq(usageCounter.metric, metric),
      ),
    )
    .limit(1);
  const used = rows.length > 0 ? rows[0].count : 0;

  if (used >= limit) return { ok: false, plan, used, limit };

  if (rows.length === 0) {
    await db
      .insert(usageCounter)
      .values({ userId, period, metric, count: 1 })
      .onConflictDoUpdate({
        target: [usageCounter.userId, usageCounter.period, usageCounter.metric],
        set: { count: sql`${usageCounter.count} + 1` },
      });
  } else {
    await db
      .update(usageCounter)
      .set({ count: sql`${usageCounter.count} + 1` })
      .where(
        and(
          eq(usageCounter.userId, userId),
          eq(usageCounter.period, period),
          eq(usageCounter.metric, metric),
        ),
      );
  }

  return { ok: true, plan, used: used + 1, limit };
}

/** Documents are capped by total count, not per month. */
export async function canAddDocument(userId: string): Promise<QuotaResult> {
  const plan = await getPlan(userId);
  const limit = LIMITS[plan].documents;
  const rows = await db
    .select({ n: sql<number>`count(*)` })
    .from(document)
    .where(eq(document.userId, userId));
  const used = Number(rows[0]?.n ?? 0);
  return { ok: used < limit, plan, used, limit };
}

/** Body returned with HTTP 402 so every client can react the same way. */
export function quotaError(r: QuotaResult) {
  return {
    error: "QUOTA_EXCEEDED" as const,
    plan: r.plan,
    used: r.used,
    limit: r.limit,
  };
}
