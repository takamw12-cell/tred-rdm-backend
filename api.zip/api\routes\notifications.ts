import { Hono, type Context } from "hono";
import { and, eq } from "drizzle-orm";
import { z } from "zod";

import { auth } from "../auth";
import { db } from "../db";
import { pushTokens } from "../db/schema/push_tokens";
import { sendNotification } from "../lib/push";

type AppEnv = {
  Variables: {
    user?: { id: string; email: string } | null;
  };
};

export const notificationsRoutes = new Hono<AppEnv>();

const registerTokenSchema = z.object({
  pushToken: z.string().min(1),
  platform: z.enum(["ios", "android"]),
  deviceName: z.string().max(120).optional(),
  appVersion: z.string().max(40).optional(),
});

async function requireUser(c: Context<AppEnv>) {
  const fromContext = c.get("user");
  if (fromContext?.id) return fromContext;

  const session = await auth.api.getSession({ headers: c.req.raw.headers });
  return session?.user ?? null;
}

/* -------------------------------------------------------------------------- */
/* POST /api/notifications/register-token             (protégé)                */
/* -------------------------------------------------------------------------- */

notificationsRoutes.post("/register-token", async (c) => {
  const user = await requireUser(c);
  if (!user) return c.json({ error: "UNAUTHORIZED" }, 401);

  const parsed = registerTokenSchema.safeParse(await c.req.json().catch(() => ({})));
  if (!parsed.success) {
    return c.json({ error: "BAD_REQUEST", issues: parsed.error.flatten() }, 400);
  }

  const { pushToken, platform, deviceName, appVersion } = parsed.data;

  try {
    // Upsert sur `push_token` (index unique) : si le même appareil se
    // reconnecte avec un autre compte, le token est réassigné au bon userId
    // au lieu de créer un doublon qui notifierait la mauvaise personne.
    await db
      .insert(pushTokens)
      .values({
        userId: user.id,
        pushToken,
        platform,
        deviceName,
        appVersion,
      })
      .onConflictDoUpdate({
        target: pushTokens.pushToken,
        set: {
          userId: user.id,
          platform,
          deviceName,
          appVersion,
          updatedAt: new Date(),
        },
      });

    return c.json({ success: true });
  } catch (error) {
    console.error("[notifications] register-token échoué:", error);
    return c.json({ error: "REGISTER_TOKEN_FAILED" }, 500);
  }
});

/* -------------------------------------------------------------------------- */
/* POST /api/notifications/unregister-token           (protégé)                */
/* -------------------------------------------------------------------------- */

notificationsRoutes.post("/unregister-token", async (c) => {
  const user = await requireUser(c);
  if (!user) return c.json({ error: "UNAUTHORIZED" }, 401);

  const body = await c.req.json().catch(() => ({}));
  const pushToken = typeof body?.pushToken === "string" ? body.pushToken : null;
  if (!pushToken) return c.json({ error: "BAD_REQUEST" }, 400);

  try {
    await db
      .delete(pushTokens)
      .where(and(eq(pushTokens.userId, user.id), eq(pushTokens.pushToken, pushToken)));
    return c.json({ success: true });
  } catch (error) {
    console.error("[notifications] unregister-token échoué:", error);
    return c.json({ error: "UNREGISTER_TOKEN_FAILED" }, 500);
  }
});

/* -------------------------------------------------------------------------- */
/* POST /api/notifications/test                       (protégé, dev only)      */
/* -------------------------------------------------------------------------- */
/* L'envoi "réel" est la fonction `sendNotification` de `lib/push.ts`, appelée
   côté serveur. Cette route sert uniquement à vérifier ton setup depuis l'app.
   Elle n'envoie qu'à SOI-MÊME : impossible de spammer un autre utilisateur.  */

notificationsRoutes.post("/test", async (c) => {
  const user = await requireUser(c);
  if (!user) return c.json({ error: "UNAUTHORIZED" }, 401);

  const result = await sendNotification({
    userId: user.id,
    title: "TRED — test",
    body: "Si tu vois ça, les push fonctionnent 🎉",
    data: { type: "test" },
  });

  return c.json(result);
});

/* -------------------------------------------------------------------------- */
/* POST /api/notifications/send                       (serveur → serveur)      */
/* -------------------------------------------------------------------------- */
/* Route interne protégée par un secret partagé, pour tes crons Railway.
   NE PAS exposer au client mobile. Retire-la si tu n'en as pas besoin.        */

notificationsRoutes.post("/send", async (c) => {
  const secret = process.env.INTERNAL_API_SECRET;
  if (!secret || c.req.header("x-internal-secret") !== secret) {
    return c.json({ error: "FORBIDDEN" }, 403);
  }

  const schema = z.object({
    userId: z.string().min(1),
    title: z.string().min(1),
    body: z.string().min(1),
    data: z.record(z.string(), z.unknown()).optional(),
  });

  const parsed = schema.safeParse(await c.req.json().catch(() => ({})));
  if (!parsed.success) {
    return c.json({ error: "BAD_REQUEST", issues: parsed.error.flatten() }, 400);
  }

  const result = await sendNotification(parsed.data);
  return c.json(result);
});

export default notificationsRoutes;
