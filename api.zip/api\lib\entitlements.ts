import { and, eq, gte, sql } from "drizzle-orm";

import { db } from "../db"; // adapte si ton export s'appelle autrement
import {
  ACTIVE_SUBSCRIPTION_STATUSES,
  subscriptions,
} from "../db/schema/subscriptions";

// ⚠️ ADAPTE CET IMPORT à ton fichier existant `usage.schema.ts`.
// Le code ci-dessous suppose une table `usage` avec au minimum :
//   userId (text), totalTokens (integer), createdAt (integer timestamp)
// Si tes colonnes s'appellent autrement (promptTokens/completionTokens,
// `tokens`, `createdAt` en ms…), seule la fonction
// `getMonthlyTokenUsage` est à retoucher — le reste ne bouge pas.
import { usage } from "../db/schema/usage.schema";

/** Quota mensuel gratuit, en tokens. Surchargeable via env sur Railway. */
export const FREE_MONTHLY_TOKEN_QUOTA = Number(
  process.env.FREE_MONTHLY_TOKEN_QUOTA ?? 100_000,
);

export type Entitlement = {
  isPro: boolean;
  status: string | null;
  currentPeriodEnd: Date | null;
  tokensUsed: number;
  tokensQuota: number;
  /** true => on peut appeler l'IA. false => on bloque. */
  canUseAI: boolean;
  reason: "pro" | "within_free_quota" | "quota_exceeded";
};

/** Premier jour du mois courant, à minuit UTC. */
function startOfCurrentMonth(): Date {
  const now = new Date();
  return new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), 1, 0, 0, 0, 0));
}

/**
 * L'utilisateur a-t-il un abonnement Pro actif ?
 * Un abonnement `canceled` reste valide jusqu'à `currentPeriodEnd` — on le
 * vérifie explicitement plutôt que de se fier au seul statut.
 */
export async function getProStatus(userId: string): Promise<{
  isPro: boolean;
  status: string | null;
  currentPeriodEnd: Date | null;
}> {
  const [row] = await db
    .select()
    .from(subscriptions)
    .where(eq(subscriptions.userId, userId))
    .limit(1);

  if (!row) {
    return { isPro: false, status: null, currentPeriodEnd: null };
  }

  const statusOk = ACTIVE_SUBSCRIPTION_STATUSES.includes(row.status);
  const periodOk = row.currentPeriodEnd ? row.currentPeriodEnd.getTime() > Date.now() : false;

  return {
    isPro: statusOk && periodOk,
    status: row.status,
    currentPeriodEnd: row.currentPeriodEnd,
  };
}

/** Somme des tokens consommés par l'utilisateur depuis le 1er du mois. */
export async function getMonthlyTokenUsage(userId: string): Promise<number> {
  const since = startOfCurrentMonth();

  const [row] = await db
    .select({
      total: sql<number>`coalesce(sum(${usage.totalTokens}), 0)`,
    })
    .from(usage)
    .where(and(eq(usage.userId, userId), gte(usage.createdAt, since)));

  return Number(row?.total ?? 0);
}

/**
 * Point d'entrée unique appelé avant tout appel IA.
 * Ne throw jamais : renvoie une décision que l'appelant traduit en 402/403.
 */
export async function getEntitlement(userId: string): Promise<Entitlement> {
  const [pro, tokensUsed] = await Promise.all([
    getProStatus(userId),
    getMonthlyTokenUsage(userId).catch((error) => {
      // Si la lecture d'usage casse, on ne bloque pas un utilisateur légitime.
      console.error("[entitlements] lecture usage échouée:", error);
      return 0;
    }),
  ]);

  if (pro.isPro) {
    return {
      isPro: true,
      status: pro.status,
      currentPeriodEnd: pro.currentPeriodEnd,
      tokensUsed,
      tokensQuota: Number.POSITIVE_INFINITY,
      canUseAI: true,
      reason: "pro",
    };
  }

  const withinQuota = tokensUsed < FREE_MONTHLY_TOKEN_QUOTA;

  return {
    isPro: false,
    status: pro.status,
    currentPeriodEnd: pro.currentPeriodEnd,
    tokensUsed,
    tokensQuota: FREE_MONTHLY_TOKEN_QUOTA,
    canUseAI: withinQuota,
    reason: withinQuota ? "within_free_quota" : "quota_exceeded",
  };
}

/** Erreur typée à catcher dans les routes agent pour renvoyer un 402. */
export class QuotaExceededError extends Error {
  readonly code = "QUOTA_EXCEEDED";
  constructor(readonly entitlement: Entitlement) {
    super(
      `Quota mensuel gratuit dépassé (${entitlement.tokensUsed}/${entitlement.tokensQuota} tokens).`,
    );
    this.name = "QuotaExceededError";
  }
}

/** Garde-fou : throw si l'utilisateur ne peut pas appeler l'IA. */
export async function assertCanUseAI(userId: string): Promise<Entitlement> {
  const entitlement = await getEntitlement(userId);
  if (!entitlement.canUseAI) {
    throw new QuotaExceededError(entitlement);
  }
  return entitlement;
}
