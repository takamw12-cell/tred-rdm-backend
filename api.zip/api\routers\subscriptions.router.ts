import { ORPCError } from "@orpc/server";
import { eq } from "drizzle-orm";
import { z } from "zod";

// Même import que dans ton `users.router.ts`
import { protectedProcedure } from "../../trpc";

import { db } from "../db";
import { subscriptions } from "../db/schema/subscriptions";
import { getEntitlement } from "../lib/entitlements";
import { getStripe } from "../lib/stripe";

/**
 * Version oRPC des routes protégées d'abonnement.
 *
 * ⚠️ Le webhook Stripe N'EST PAS ici et ne doit pas y être : il a besoin du
 * corps brut pour vérifier la signature. Il reste en Hono pur dans
 * `routes/subscriptions.ts`.
 *
 * Si ton `protectedProcedure` est du **tRPC** et non du oRPC, la conversion est
 * mécanique — voir le bloc commenté en bas de fichier.
 */

const createCheckoutInput = z.object({
  priceId: z.string().min(1),
  successUrl: z.string().url().optional(),
  cancelUrl: z.string().url().optional(),
});

export const subscriptionsRouter = {
  /** Statut d'abonnement + consommation, pour l'écran Paywall. */
  me: protectedProcedure.handler(async ({ context }) => {
    const entitlement = await getEntitlement(context.session.user.id);
    return {
      isPro: entitlement.isPro,
      status: entitlement.status,
      currentPeriodEnd: entitlement.currentPeriodEnd,
      tokensUsed: entitlement.tokensUsed,
      tokensQuota: Number.isFinite(entitlement.tokensQuota) ? entitlement.tokensQuota : null,
      canUseAI: entitlement.canUseAI,
    };
  }),

  createCheckout: protectedProcedure
    .input(createCheckoutInput)
    .handler(async ({ input, context }) => {
      const user = context.session.user;
      const appUrl = process.env.APP_URL ?? "https://tred.app";

      try {
        const stripe = getStripe();

        const [existing] = await db
          .select()
          .from(subscriptions)
          .where(eq(subscriptions.userId, user.id))
          .limit(1);

        let customerId = existing?.stripeCustomerId ?? null;

        if (!customerId) {
          const customer = await stripe.customers.create({
            email: user.email ?? undefined,
            name: user.name ?? undefined,
            metadata: { userId: user.id },
          });
          customerId = customer.id;

          await db
            .insert(subscriptions)
            .values({ userId: user.id, stripeCustomerId: customerId, status: "incomplete" })
            .onConflictDoUpdate({
              target: subscriptions.userId,
              set: { stripeCustomerId: customerId, updatedAt: new Date() },
            });
        }

        const session = await stripe.checkout.sessions.create({
          mode: "subscription",
          customer: customerId,
          line_items: [{ price: input.priceId, quantity: 1 }],
          client_reference_id: user.id,
          metadata: { userId: user.id },
          subscription_data: { metadata: { userId: user.id } },
          allow_promotion_codes: true,
          success_url:
            input.successUrl ?? `${appUrl}/subscription/success?session_id={CHECKOUT_SESSION_ID}`,
          cancel_url: input.cancelUrl ?? `${appUrl}/subscription/cancel`,
        });

        if (!session.url) {
          throw new ORPCError("INTERNAL_SERVER_ERROR", { message: "Stripe n'a pas renvoyé d'URL" });
        }

        return { url: session.url, sessionId: session.id };
      } catch (error) {
        if (error instanceof ORPCError) throw error;
        console.error("[stripe] createCheckout échoué:", error);
        throw new ORPCError("BAD_GATEWAY", { message: "Création de la session Stripe impossible" });
      }
    }),

  /** Ouvre le portail client Stripe (changer de carte, annuler…). */
  portal: protectedProcedure.handler(async ({ context }) => {
    const [row] = await db
      .select()
      .from(subscriptions)
      .where(eq(subscriptions.userId, context.session.user.id))
      .limit(1);

    if (!row?.stripeCustomerId) {
      throw new ORPCError("NOT_FOUND", { message: "Aucun client Stripe pour cet utilisateur" });
    }

    try {
      const portal = await getStripe().billingPortal.sessions.create({
        customer: row.stripeCustomerId,
        return_url: `${process.env.APP_URL ?? "https://tred.app"}/settings`,
      });
      return { url: portal.url };
    } catch (error) {
      console.error("[stripe] portal échoué:", error);
      throw new ORPCError("BAD_GATEWAY", { message: "Portail Stripe indisponible" });
    }
  }),
};

/* ==========================================================================
 * ÉQUIVALENT tRPC v11 — si ton `trpc.ts` est du tRPC, remplace le bloc
 * ci-dessus par celui-ci. Seules 3 choses changent :
 *   .handler(({ context }))  ->  .query/.mutation(({ ctx }))
 *   ORPCError                ->  TRPCError({ code, message })
 *   objet littéral           ->  router({ ... })
 *
 * import { TRPCError } from "@trpc/server";
 * import { router, protectedProcedure } from "../../trpc";
 *
 * export const subscriptionsRouter = router({
 *   me: protectedProcedure.query(async ({ ctx }) => {
 *     return getEntitlement(ctx.session.user.id);
 *   }),
 *
 *   createCheckout: protectedProcedure
 *     .input(createCheckoutInput)
 *     .mutation(async ({ input, ctx }) => {
 *       // ... corps identique, avec ctx.session.user au lieu de context.session.user
 *       // en cas d'erreur :
 *       // throw new TRPCError({ code: "BAD_GATEWAY", message: "..." });
 *     }),
 * });
 * ========================================================================== */
