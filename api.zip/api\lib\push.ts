import * as ExpoServerSdk from "expo-server-sdk";
import { eq, inArray } from "drizzle-orm";

import { db } from "../db";
import { pushTokens } from "../db/schema/push_tokens";

const { Expo } = ExpoServerSdk;
type ExpoPushMessage = ExpoServerSdk.ExpoPushMessage;
type ExpoPushTicket = ExpoServerSdk.ExpoPushTicket;

let _expo: InstanceType<typeof Expo> | null = null;

function getExpo() {
  if (_expo) return _expo;
  _expo = new Expo({
    // Requis seulement si tu as activé "Enhanced Security for Push Notifications"
    // dans expo.dev. Sinon laisser undefined fonctionne très bien.
    accessToken: process.env.EXPO_ACCESS_TOKEN,
  });
  return _expo;
}

export type SendNotificationInput = {
  userId: string;
  title: string;
  body: string;
  data?: Record<string, unknown>;
  /** Badge iOS, son, priorité… surcharges optionnelles. */
  sound?: "default" | null;
  badge?: number;
  channelId?: string;
};

export type SendNotificationResult = {
  sent: number;
  failed: number;
  removedTokens: string[];
};

/**
 * Envoie une notification push à TOUS les appareils d'un utilisateur.
 *
 * Ne throw JAMAIS : une notif ratée ne doit pas faire échouer la requête
 * métier qui l'a déclenchée (génération de Klausur, webhook, cron…).
 * Retourne un résumé exploitable pour les logs.
 */
export async function sendNotification(
  input: SendNotificationInput,
): Promise<SendNotificationResult> {
  const result: SendNotificationResult = { sent: 0, failed: 0, removedTokens: [] };

  try {
    const rows = await db
      .select({ pushToken: pushTokens.pushToken })
      .from(pushTokens)
      .where(eq(pushTokens.userId, input.userId));

    // Filtre les tokens malformés (app désinstallée, token tronqué…).
    const valid: string[] = [];
    const invalid: string[] = [];
    for (const row of rows) {
      (Expo.isExpoPushToken(row.pushToken) ? valid : invalid).push(row.pushToken);
    }

    if (invalid.length > 0) {
      await removeTokens(invalid);
      result.removedTokens.push(...invalid);
    }

    if (valid.length === 0) {
      return result;
    }

    const messages: ExpoPushMessage[] = valid.map((to) => ({
      to,
      title: input.title,
      body: input.body,
      data: input.data ?? {},
      sound: input.sound === null ? undefined : (input.sound ?? "default"),
      badge: input.badge,
      channelId: input.channelId ?? "default",
      priority: "high",
    }));

    const expo = getExpo();
    const chunks = expo.chunkPushNotifications(messages);
    const tickets: ExpoPushTicket[] = [];

    for (const chunk of chunks) {
      try {
        const chunkTickets = await expo.sendPushNotificationsAsync(chunk);
        tickets.push(...chunkTickets);
      } catch (error) {
        result.failed += chunk.length;
        console.error("[push] envoi d'un chunk échoué:", error);
      }
    }

    // Nettoyage : Expo signale les appareils désinscrits via DeviceNotRegistered.
    const deadTokens: string[] = [];
    tickets.forEach((ticket, index) => {
      if (ticket.status === "ok") {
        result.sent += 1;
        return;
      }
      result.failed += 1;
      console.error("[push] ticket en erreur:", ticket.message, ticket.details);
      if (ticket.details?.error === "DeviceNotRegistered") {
        const token = valid[index];
        if (token) deadTokens.push(token);
      }
    });

    if (deadTokens.length > 0) {
      await removeTokens(deadTokens);
      result.removedTokens.push(...deadTokens);
    }

    return result;
  } catch (error) {
    console.error("[push] sendNotification a échoué:", error);
    return result;
  }
}

/** Variante fire-and-forget : à utiliser dans un `onFinish` de stream. */
export function sendNotificationSafe(input: SendNotificationInput): void {
  void sendNotification(input).catch((error) => {
    console.error("[push] sendNotificationSafe:", error);
  });
}

/** Envoi groupé à plusieurs utilisateurs (rappels de révision, annonces…). */
export async function sendNotificationToUsers(
  userIds: string[],
  payload: Omit<SendNotificationInput, "userId">,
): Promise<void> {
  await Promise.all(userIds.map((userId) => sendNotification({ ...payload, userId })));
}

async function removeTokens(tokens: string[]): Promise<void> {
  try {
    await db.delete(pushTokens).where(inArray(pushTokens.pushToken, tokens));
    console.log(`[push] ${tokens.length} token(s) invalide(s) supprimé(s)`);
  } catch (error) {
    console.error("[push] suppression des tokens échouée:", error);
  }
}

/* -------------------------------------------------------------------------- */
/* Helpers métier TRED                                                        */
/* -------------------------------------------------------------------------- */

export function notifyKlausurReady(params: {
  userId: string;
  klausurId?: string;
  subject?: string;
  conversationId?: string;
}): void {
  sendNotificationSafe({
    userId: params.userId,
    title: "Deine Klausur ist bereit 📝",
    body: params.subject
      ? `Ton exercice de ${params.subject} vient d'être généré. Prêt à t'entraîner ?`
      : "Ton exercice vient d'être généré. Prêt à t'entraîner ?",
    data: {
      type: "klausur_ready",
      klausurId: params.klausurId,
      conversationId: params.conversationId,
    },
  });
}

export function notifyQuotaExceeded(userId: string): void {
  sendNotificationSafe({
    userId,
    title: "Quota mensuel atteint",
    body: "Passe à TRED Pro pour continuer à générer des Klausuren sans limite.",
    data: { type: "quota_exceeded", screen: "paywall" },
  });
}
